# OI-CBF 项目工作归档

归档日期：2026-11-08  
项目：OI-CBF  
原工作目录：`C:\Users\lu_ke\Documents\GitHub\OI-CBF`  
论文：*Safety-Critical Control with Bounded Inputs: A Closed-Form Solution for Backup Control Barrier Functions*，arXiv:2510.05436v1。

## 1. 归档结论

已完成用户要求的三项工作：Python 源码与论文数学公式核对、Python 到 MATLAB 的转换、MATLAB 与论文公式的一致性验证。后续已接入 Optimization Toolbox、Symbolic Math Toolbox 和 Parallel Computing Toolbox，并完成实际运行验证。

默认两个模型、三种控制器均可正常仿真，MATLAB 与 Python 的默认轨迹高度一致；与此同时，审查发现了源码偏差、不可行性处理缺失及论文负转弯半径的反例。因此本次交付支持“实现与数值复现得到验证”，不支持“所有状态与参数下的安全性已经证明”。

本归档包含代码快照、论文副本、说明、结构化结果、参考数据、仿真输出及逐文件 SHA-256 清单；未包含 Python 虚拟环境、MATLAB 安装目录或 Git 数据库。

## 2. 用户要求与完成状态

| 工作项 | 完成情况 | 交付证据 |
|---|---|---|
| 测试 Python 源码与论文公式是否一致 | 已完成逐式对应、数值核验、差异和反例分析 | `test_results/MATH_AND_MATLAB_REPORT.md`、两个 `*_paper_audit.json` |
| 将 Python 转换为 MATLAB | 已实现双积分器、飞机、三种控制器、仿真和绘图 | `matlab/`、`matlab/README.md` |
| 测试 MATLAB 与论文公式是否一致 | 已完成独立公式、有限差分、符号推导、QP 和跨语言检查 | `test_results/matlab/*validation.json` |
| Optimization Toolbox | 已支持可选 quadprog，并与投影求解器及 Python 对照 | `validate_toolbox.m`、`toolbox_validation.json` |
| Symbolic Math Toolbox | 已独立符号推导雅可比及安全函数梯度 | `validate_symbolic.m`、`symbolic_validation.json` |
| Parallel Computing Toolbox | 已实现批量初始条件测试，并验证串行/并行一致性 | `run_batch_tests.m`、`validate_parallel.m`、`parallel_validation.json` |

## 3. 完成的实现

### MATLAB 主程序

- 两个模型：双积分器、八状态固定翼飞机。
- 三种安全控制：bCBF、指数函数 blending、OI 闭式控制；另保留标称控制模式。
- 动力学、标称/备份控制、安全函数、解析梯度与闭环雅可比。
- 备份状态流、完整 STM 和方向导数传播。
- 一维/二维凸集投影 QP 求解器，以及 MATLAB quadprog 可选接口。
- 零阶保持仿真、全部状态/输入记录、备份轨迹、耗时统计与原生绘图。
- 稳定 softplus/soft-min 数值表达，以及显式不可行性处理。
- 符号公式检查、串行/并行批量测试和统一验证入口。

最终 MATLAB 程序目录共有 23 个 `.m` 文件；另有验证阶段生成的符号雅可比文件，位于结果目录，不计入这 23 个文件。

### 两种配置及原代码保留原则

- `source`：保留原 Python 的参数及数学选择，用于忠实复现。
- `paper`：对有符号航向误差、未归一化高度约束、终端 alphaB、预测零时刻和额外收紧项作显式区分，用于字面公式核对。论文未公开的数值细节仍沿用源码，不能当作独立复现全部论文细节。
- 两种配置均保留论文原式的半径约定；只有显式设定 `radiusConvention='signed-corrected'` 才采用审查提出的几何修订。
- MATLAB 默认 `failurePolicy='error'`，检测到不可行时停止；`legacy` 仅用于复现原 Python 的缺陷。
- 原始 Python 文件和原有 `aircraft/matlab/` 符号脚本未修改；Python 原文件 SHA-256 可与审查 JSON 对照。

## 4. 实测结果摘要

| 验证 | 实测结论 |
|---|---|
| 初始 Python 默认仿真 | 两个模型各三种控制器全部完成，无检测到的采样安全越界或输入超限 |
| MATLAB 数学检查 | 57 项全部通过，范围包括公式对应、导数、QP、数值稳定性及已知反例的成功复现 |
| 自定义投影求解器 | 80 组 Python quadprog 参考问题，72 可行、8 不可行，判断一致；最大输入差约 1.05e-15 |
| MATLAB 论文配置 | 两个模型各 3 个状态，独立重建 OI 约束；飞机最大系数差约 3.86e-8 |
| MATLAB 六组完整默认仿真 | 全部完成，默认安全与输入检查通过，跨语言轨迹比较通过 |
| MATLAB quadprog | 80 组问题判断一致；与 Python 最大控制差约 8.05e-16，OI 闭式解最大差约 1.11e-16 |
| quadprog 完整 bCBF 仿真 | 两个模型均完成，全部 QP 可行；飞机轨迹与投影求解器最大差约 1.64e-11 |
| 符号验证 | 飞机 12 个状态的最大雅可比差约 2.84e-14、分量梯度差约 4.55e-13；相关符号恒等式通过 |
| 串行/并行对照 | 18 个短时场景的结果分类与数值完全一致，最大数值差 0；14 完成、4 不可行、0 其他错误 |
| 并行压力场景的安全结果 | 1 个显式加入的飞机 blending 已知反例越过围栏；不能将并行一致性通过解释为全部场景安全 |
| Code Analyzer | 最后一次检查 23 个 MATLAB 文件，0 项诊断 |

完整默认仿真：双积分器推进 351 步、7.02 s；飞机推进 734 步、110.10 s。时长保留原源码的数组/步数约定。

### MATLAB 与 Python 的完整默认轨迹比较

| 模型 | 控制器 | 最大状态分量差 | 最大输入差 |
|---|---|---:|---:|
| 双积分器 | bCBF | 6.66e-16 | 5.55e-15 |
| 双积分器 | blending | 2.11e-15 | 2.04e-14 |
| 双积分器 | OI | 6.66e-16 | 7.11e-15 |
| 飞机 | bCBF | 2.96e-4 | 4.94e-6 |
| 飞机 | blending | 1.91e-5 | 1.01e-8 |
| 飞机 | OI | 2.07e-4 | 4.76e-6 |

飞机上表最大的状态差出现在以米计的位置/高度分量；全组位置最大差约为 0.000296 m。不同状态单位混合，逐分量数据以 `simulation_validation.json` 为准。有限容差比较不要求浮点逐位相等。

并行验证中计算时间约为串行 3.10 s、并行 2.36 s，但创建池约 14.35 s。本次小规模测试含启动后的总耗时更长；未声称单次仿真或整体工作流必然加速。

## 5. 已发现的问题与尚未消除的限制

### Python 与论文的差异

1. 飞机标称控制对航向误差取绝对值，与论文有符号表达不同，会改变转弯方向。
2. 高度约束被单独归一化；单约束零集不变，但六项 soft-min 的值、梯度权重和备份集会改变。
3. 飞机 OI 终端项使用 `alpha`，bCBF 使用 `alpha_b`；本地增益分别为 0.072 和 0.5。
4. 源码加入额外离散收紧并跳过预测零时刻；这些实现选择不能直接等同于论文原式。
5. 固定 `sup_fcl` 常数在默认初始状态下并非备份动力学范数或安全函数变化率的上界。

### OI 输入超限反例

双积分器状态 `[-0.128,0.5]` 可由备份控制安全制动，但原 Python OI 得到 `mu≈1.02045452`、`u≈-1.04090904`，违反 `[-1,1]` 的输入限制。其原因是给定状态与参数下 QP 不可行，而源码没有检查闭式最大下界是否满足所有上界/残差。

MATLAB 默认对此报明确错误；该处理避免输出超限值，但不代替对可行状态域、增益和备份集合的重新验证。

### 论文与源码共享的负半径反例

按用户提供论文第 7 页字面公式及 `phi_star=-pi/4`，转弯半径为负。取理想转弯状态、北向位置 `26000 m`，得到 `h=-1000`、`h6≈3072.47>0`，即满足论文所写备份集条件却不属于安全集。源码也沿用了该表达式。

将北向位置改为 `24990 m` 时，初始安全且 soft-min 备份函数为正，但沿备份控制仍会越界。并行压力测试中相应 blending 场景也复现越界；这不是并行计算造成的差异。

建议与作者核实半径符号约定。可选修订 `h6=h+rho*n_g'*n(psi)-abs(rho)-c6` 仅修订圆轨迹几何条件，尚未证明近似备份邻域与整个采样控制器的安全性。

### 其他说明

- 原 Python 在部分工况下的指数计算会溢出；MATLAB 使用等价稳定表达式。
- 原 Python 的平均/最大求解耗时返回空列表；MATLAB 已实际计算。
- 早期 Python 默认绘图依赖系统 LaTeX；MATLAB 绘图不依赖外部 LaTeX。
- MATLAB 的符号推导检查不会自动证明全局安全性、不变性或所有增益下的 QP 可行性。
- 本次未穷举状态域、未进行硬件/实时部署、未重现论文全部未公开数值细节。

## 6. 环境与依赖

- Windows；原 Python 验证环境为 Python 3.12.14，依赖由根目录 `requirements.txt` 锁定。
- 独立 Python 环境位于 `.test-environment/`，未装入归档；换机需重建。
- 基础 MATLAB 验证在 R2026b 完成，符号/并行后续验证在 R2026b Update 1 完成；确切版本号见对应 JSON。
- 已实际确认可用的工具箱：Optimization、Symbolic Math、Parallel Computing。
- 默认投影模式的仿真不依赖这些附加工具箱；统一验证入口会在检测到工具箱后增加相应验证。

## 7. 复现方法

解压归档后，将 MATLAB 当前目录切到项目根目录：

```matlab
addpath('matlab');
run_comparison('double_integrator','source');
run_comparison('aircraft','source');
report = run_validation();
```

显式使用 Optimization Toolbox：

```matlab
run_comparison('aircraft','source',[],'quadprog');
```

单独使用新工具箱：

```matlab
validate_symbolic();
validate_parallel();
batch = run_batch_tests(6,'parallel',2);
```

批量测试示例为每模型 6 个状态、每状态 3 个控制器，共 36 个短时场景；每场景 40 个控制步，不能替代完整时域仿真。函数关闭自己创建的并行池，保留用户已有的池。

归档中已包含当前验证所需的参考 MAT 文件。重新生成 Python 参考数据时，先重建 Python 环境、安装 `requirements.txt`，再按照 `matlab/README.md` 的顺序执行 `tests/` 下的脚本。

## 8. 文件索引与可信结果顺序

| 文件/目录 | 用途 |
|---|---|
| `ARCHIVE_SUMMARY.md` | ZIP 内本归档总结 |
| `ARCHIVE_MANIFEST.json` | 逐文件路径、字节数、SHA-256 及构建时验证摘要 |
| `paper/1048550arXiv251005436.pdf` | 用户提供论文副本 |
| `matlab/README.md` | MATLAB 使用说明、配置含义与脚本对应 |
| `matlab/+oicbf/` | MATLAB 核心数值实现 |
| `matlab/validate_*.m`、`run_validation.m` | 独立与统一验证入口 |
| `tests/` | Python 初始测试、数学审查和参考数据生成 |
| `test_results/MATH_AND_MATLAB_REPORT.md` | 逐式核查、反例推导与补充工具箱验证 |
| `test_results/TEST_REPORT.md` | 较早的首次源码运行检查；后续结论以完整报告为准 |
| `test_results/*_paper_audit.json` | Python 数学审查及原始源文件 SHA-256 |
| `test_results/*_reference.mat` | 跨语言及独立 QP 参考 |
| `test_results/matlab/*validation.json` | 各项权威结构化结果 |
| `test_results/matlab/batch_*.json` | 包含已知反例的逐场景执行结果 |
| `test_results/matlab/code_analyzer.json` | 最新 MATLAB 静态诊断摘要 |
| `test_results/matlab/*_bCBF.mat`、`*_OI.mat` 等 | 完整 MATLAB 仿真结果 |
| `test_results/matlab/aircraft/`、`double_integrator/` | MATLAB 状态、控制与轨迹图 |

早期 `validation_summary.mat`、`code_analyzer.mat` 为旧版汇总，不代表工具箱接入后的完整状态，因此不放入本归档；以逐项 JSON 及最新文档为准。

## 9. 当前工程状态与后续工作边界

归档时 Git 工作区中的 `matlab/`、`tests/`、`test_results/` 为新增且尚未提交的目录；本次工作未执行 Git 提交、推送或发布。归档 ZIP 已直接包含这些新增代码和相关结果，不能只依赖原仓库的已提交历史恢复工作。

可后续推进但尚未声称完成的工作：与作者核实论文符号/参数约定；在明确修订方案后重新推导备份集和可行域；扩大初始条件、扰动与步长测试；根据大规模负载实测并行收益；按部署需求补充实时性和硬件验证。
